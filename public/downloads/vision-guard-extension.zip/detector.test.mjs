import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Detector,FastDetector,RegionalFlashDetector,covered} from './detector.mjs';
function frame(value){const data=new Uint8ClampedArray(96*54*4);for(let i=0;i<data.length;i+=4){data[i]=data[i+1]=data[i+2]=value;data[i+3]=255;}return data;}

test('Fast mode holds an isolated cut briefly and releases a one-way fade', () => {
  const detector = new FastDetector();
  assert.equal(detector.inspect(0, frame(32)), 'show');
  assert.equal(detector.inspect(50, frame(150)), 'hold');
  for (const [now, value] of [[100,175], [150,200], [200,225], [250,250]]) {
    assert.equal(detector.inspect(now, frame(value)), 'hold');
  }
  assert.equal(detector.inspect(275, frame(255)), 'show');
  assert.equal(detector.inspect(500, frame(255)), 'show');
});

test('regional dimming ignores isolated flashes, slow alternation and weak flicker', () => {
  for (const [low,high,step,frames] of [[20,240,60,3],[20,240,210,30],[100,106,45,30],[240,255,50,30]]) {
    const detector = new RegionalFlashDetector();
    for (let i = 0; i < frames; i++) assert.equal(detector.inspect(i*step,frame(i%2 ? high : low)),0);
  }
});

test('regional dimming isolates repeated saturated red with little luminance change and releases smoothly', () => {
  const detector = new RegionalFlashDetector(), base = frame(110), pulse = base.slice();
  for (let y=0; y<12; y++) for (let x=0; x<12; x++) {
    pulse.set([220,0,0,255],(y*96+x)*4);
  }
  for (let i=0;i<7;i++) assert.equal(detector.inspect(i*60,i%2 ? pulse : base),0);
  assert.equal(detector.inspect(420,pulse),4);
  assert.equal(detector.opacity[0],228);
  assert.equal(detector.opacity[3],0);
  assert.equal(detector.inspect(790,pulse),4);
  assert.ok(detector.opacity[0] > 0 && detector.opacity[0] < 228);
  assert.equal(detector.inspect(881,pulse),0);
});

test('Fast mode confirms a reversal in the same region and releases quiet footage', () => {
  const dark = frame(56);
  function patch(startX) {
    const pixels = dark.slice();
    for (let y = 9; y < 27; y++) {
      for (let x = startX; x < startX + 24; x++) {
        const offset = (y * 96 + x) * 4;
        pixels.fill(235, offset, offset + 3);
      }
    }
    return pixels;
  }
  const detector = new FastDetector();
  const left = patch(0), right = patch(72);
  detector.inspect(0, left);
  assert.equal(detector.inspect(40, dark), 'hold');
  assert.equal(detector.inspect(100, right), 'hold'); // Different region.
  assert.equal(detector.inspect(150, dark), 'filter');
  assert.equal(detector.inspect(350, dark), 'filter');
  assert.equal(detector.inspect(440, dark), 'show');
  assert.equal(detector.inspect(600, right), 'hold'); // Previous reversal expired.
});

test('Fast mode filters dense high-contrast stripes on the first frame', () => {
  const stripes = frame(0);
  for (let i = 4; i < stripes.length; i += 8) stripes.fill(255, i, i + 3);
  assert.equal(new FastDetector().inspect(0, stripes), 'filter');
});

function pattern(levelAt) {
  const pixels = frame(0);
  for (let y = 0; y < 54; y++) {
    for (let x = 0; x < 96; x++) {
      const offset = (y * 96 + x) * 4;
      pixels.fill(levelAt(x, y), offset, offset + 3);
    }
  }
  return pixels;
}

test('smooth luminance reversals are recognized across frame rates', () => {
  for (const fps of [24, 30, 60, 120]) {
    const detector = new FastDetector();
    let first = Infinity;
    const scan = new Detector();
    for (let i = 0; i <= fps; i++) {
      const time = i * 1000 / fps;
      const level = Math.round(126 - 24 * Math.cos(time * 2 * Math.PI / 200));
      const pixels = frame(level);
      if (detector.inspect(time, pixels) === 'filter') first = Math.min(first, time);
      scan.push(time / 1000, pixels);
    }
    assert.ok(first <= 220, `No timely reversal at ${fps} fps: ${first}`);
    assert.ok(covered(0.5, scan.intervals), `Missing pre-scan interval at ${fps} fps`);
  }
});

test('a slow exposure change and a camera fade do not confirm flicker', () => {
  const detector = new FastDetector();
  for (let i = 0; i <= 240; i++) {
    const level = Math.round(124 - 50 * Math.cos(i * 2 * Math.PI / 240));
    assert.notEqual(detector.inspect(i * 1000 / 60, frame(level)), 'filter');
  }
});

test('pre-scan requires seven alternating luminance changes within a one-second window', () => {
  const dark = frame(64), bright = frame(145);
  function scan(times) {
    const detector = new Detector();
    detector.push(0, dark);
    times.forEach((time, index) => detector.push(time, index % 2 ? dark : bright));
    return detector.intervals.length;
  }
  assert.equal(scan([.1,.2,.3,.4,.5,.6]), 0);
  assert.equal(scan([.1,.2,.3,.4,.5,.6,.7]), 1);
  assert.equal(scan([.1,.2,.4,.6,.8,1,1.1]), 0);
});

test('regular bands in three orientations are detected across playback modes', () => {
  for (const position of [(x) => x, (_, y) => y, (x, y) => x + y]) {
    const bands = pattern((x, y) => Math.floor(position(x, y) / 3) % 2 ? 232 : 32);
    const scan = new Detector();
    scan.push(0, bands);
    assert.equal(scan.intervals.length, 1);
    assert.equal(new FastDetector().inspect(0, bands), 'filter');
  }
});

test('still irregular texture and single edges do not count as repeating bands', () => {
  let seed = 731;
  const noise = pattern(() => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed >>> 31 ? 255 : 0;
  });
  for (const pixels of [noise, pattern((x) => x < 48 ? 0 : 255)]) {
    const scan = new Detector();
    scan.push(0, pixels);
    assert.equal(scan.intervals.length, 0);
    assert.equal(new FastDetector().inspect(0, pixels), 'show');
  }
});
test('known strobe interval is mapped before playback',()=>{const d=new Detector();for(let i=0;i<360;i++){const t=i/60;d.push(t,frame(t>=2 && t<4 ? (Math.floor(t*16)%2?255:0):100));}assert.equal(d.intervals.length,1);assert.ok(d.intervals[0].start<=2);assert.ok(d.intervals[0].end>=4);assert.ok(!covered(0,d.intervals));assert.ok(covered(3,d.intervals));assert.ok(!covered(5.9,d.intervals));});
test('steady content does not fabricate hazard intervals',()=>{const d=new Detector();for(let i=0;i<180;i++)d.push(i/60,frame(100));assert.deepEqual(d.intervals,[]);});
test('timestamp lookup handles seeks and speed independently',()=>{const intervals=[{start:2,end:4}];for(const [t,want] of [[3,true],[1,false],[4,true],[7,false],[2,true]])assert.equal(covered(t,intervals),want);});
test('rejects malformed frames and nonmonotonic time',()=>{const d=new Detector();assert.throws(()=>d.push(0,new Uint8Array(4)),RangeError);const e=new Detector();e.push(0,frame(100));assert.throws(()=>e.push(0,frame(100)),RangeError);assert.throws(()=>e.push(NaN,frame(100)),RangeError);});
test('binary lookup preserves inclusive interval boundaries',()=>{const intervals=Array.from({length:1000},(_,i)=>({start:i*3,end:i*3+1}));for(let t=0;t<3000;t+=.5)assert.equal(covered(t,intervals),intervals.some(i=>t>=i.start&&t<=i.end));assert.equal(covered(NaN,intervals),false);});

test('red-only transitions include the one-second boundary and expire after it', () => {
  const dark = frame(0);
  const red = frame(0);
  // Red intensity changes by >0.2 while luminance changes by <0.1.
  for (let i = 0; i < red.length; i += 4) red[i] = 135;

  function analyze(lastTransition) {
    const detector = new Detector();
    detector.push(0, dark);
    const times = [1, 1.2, 1.4, 1.6, 1.8, lastTransition];
    times.forEach((time, i) => detector.push(time, i % 2 ? dark : red));
    return detector.intervals;
  }

  assert.deepEqual(analyze(2), [{ start: 0.75, end: 2.5 }]);
  assert.deepEqual(analyze(2.01), []);
});

test('isolated changes can be covered before they form a repeated hazard', () => {
  const detector = new Detector();
  assert.equal(detector.candidateTransition, false);
  detector.push(0, frame(0));
  assert.equal(detector.candidateTransition, false);
  detector.push(0.1, frame(255));
  assert.equal(detector.candidateTransition, true);
  assert.deepEqual(detector.intervals, []);
  detector.push(0.2, frame(255));
  assert.equal(detector.candidateTransition, false);
  detector.push(0.3, frame(0));
  assert.equal(detector.candidateTransition, true);
});

test('candidate includes red changes of similar luminance and first-frame spatial patterns', () => {
  const green = frame(0);
  const red = frame(0);
  const stripes = frame(0);
  for (let i = 0; i < red.length; i += 4) {
    red[i] = 135;
    green[i + 1] = 76;
    if ((i / 4) % 2) stripes[i] = stripes[i + 1] = stripes[i + 2] = 255;
  }

  const chromatic = new Detector();
  chromatic.push(0, green);
  chromatic.push(0.03, red);
  assert.equal(chromatic.candidateTransition, true);
  assert.deepEqual(chromatic.intervals, []);

  const spatial = new Detector();
  spatial.push(0, stripes);
  assert.equal(spatial.candidateTransition, true);
  spatial.push(0.03, frame(64));
  spatial.push(0.06, frame(64));
  assert.equal(spatial.candidateTransition, false);
});

test('near-equal-luminance non-red swaps affect only candidates above the strict area cutoff', () => {
  // Pure green at 89 and blue at 255 both have relative luminance about 0.072.
  const green = frame(0);
  for (let i = 1; i < green.length; i += 4) green[i] = 89;
  function switched(count) {
    const result = green.slice();
    for (let i = 0; i < count * 4; i += 4) { result[i + 1] = 0; result[i + 2] = 255; }
    return result;
  }
  const small = new Detector();
  small.push(0, green);
  small.push(0.05, switched(259)); // 4.996% of the frame.
  assert.equal(small.candidateTransition, false);

  const large = new Detector();
  const swapped = switched(260);
  large.push(0, green);
  for (let i = 1; i <= 12; i++) {
    large.push(i / 20, i % 2 ? swapped : green);
    assert.equal(large.candidateTransition, true);
  }
  large.push(0.65, green);
  assert.equal(large.candidateTransition, false);
  assert.deepEqual(large.intervals, []);
});
